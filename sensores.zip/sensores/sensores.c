#include "sensores.h"
#include "driver/adc.h"

#define ADC_WIDTH        ADC_WIDTH_BIT_12         // 12 bits = 0-4095
#define ADC_ATTENUATION  ADC_ATTEN_DB_11          // Hasta ~3.3 V
#define ADC_CHANNEL      ADC1_CHANNEL_0           // GPIO36

#define VREF             3.3                      // Voltaje de referencia
#define RESOLUCION       4095.0                   // Máximo ADC

#define MAX_VUELTAS      10.0                     // Potenciómetro de 10 vueltas

void sensores_init(void) {
    adc1_config_width(ADC_WIDTH);
    adc1_config_channel_atten(ADC_CHANNEL, ADC_ATTENUATION);
}

int leer_potenciometro(void) {
    return adc1_get_raw(ADC_CHANNEL);  // 0–4095
}

float leer_potenciometro_voltios(void) {
    int raw = leer_potenciometro();
    return ((float)raw / RESOLUCION) * VREF;
}

float leer_potenciometro_vueltas(void) {
    int raw = leer_potenciometro();
    return ((RESOLUCION - raw) / RESOLUCION) * MAX_VUELTAS;
}

