#pragma once

void sensores_init(void);
int leer_potenciometro(void);
float leer_potenciometro_voltios(void);
float leer_potenciometro_vueltas(void);
