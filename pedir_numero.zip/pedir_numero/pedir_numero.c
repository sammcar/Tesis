#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "pedir_numero.h"

void pedirNumero(char *buffer, int *numero) {
    printf("Ingrese un numero: ");
    fflush(stdout);

    int index = 0;
    int c;
    // Limpiamos el buffer
    memset(buffer, 0, 20);

    // Acumula caracteres hasta encontrar un salto de línea (Enter)
    while (1) {
        c = getchar();
        if (c == EOF) {
            // No hay dato disponible, espera un poco y vuelve a intentar
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }
        // Si se detecta el Enter, finaliza la lectura
        if (c == '\n') {
            break;
        }
        // Se almacenan hasta 19 caracteres (dejando espacio para el '\0')
        if (index < 19) {
            buffer[index++] = (char)c;
        }
    }
    buffer[index] = '\0'; // Terminación nula

    // Convierte la cadena a entero
    if (sscanf(buffer, "%d", numero) == 1) {
        printf("El doble es: %d\n", (*numero) * 2);
    } else {
        printf("Error al convertir el numero. Asegurate de ingresar un valor numerico.\n");
    }
    
    // Pequeña pausa para evitar saturar el CPU
    vTaskDelay(pdMS_TO_TICKS(100));
}
