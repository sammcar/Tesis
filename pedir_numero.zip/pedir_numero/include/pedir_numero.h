#ifndef PEDIR_NUMERO_H
#define PEDIR_NUMERO_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Lee una línea completa de entrada hasta detectar un Enter y
 *        convierte la cadena a un número entero.
 *
 * @param buffer Buffer para almacenar la línea leída (debe tener al menos 20 bytes).
 * @param numero Puntero a la variable donde se guardará el número convertido.
 */
void pedirNumero(char *buffer, int *numero);

#ifdef __cplusplus
}
#endif

#endif // PEDIR_NUMERO_H
