#pragma once

#include "driver/gpio.h"
#include <stdbool.h>

typedef struct {
    gpio_num_t step_pin;
    gpio_num_t dir_pin;
    gpio_num_t enable_pin;
    int steps_per_rev;
} stepper_motor_t;

void stepper_motor_init(stepper_motor_t *motor);
void stepper_motor_enable(stepper_motor_t *motor);
void stepper_motor_disable(stepper_motor_t *motor);
void stepper_motor_step(stepper_motor_t *motor, int steps, bool direction, int delay_us);
