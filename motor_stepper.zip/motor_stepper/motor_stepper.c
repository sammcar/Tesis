#include "motor_stepper.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_rom_sys.h" 
#include "esp_log.h" 

#define TAG "STEPPER"

void stepper_motor_init(stepper_motor_t *motor) {
    gpio_set_direction(motor->step_pin, GPIO_MODE_OUTPUT);
    gpio_set_direction(motor->dir_pin, GPIO_MODE_OUTPUT);
    gpio_set_direction(motor->enable_pin, GPIO_MODE_OUTPUT);

    gpio_set_level(motor->enable_pin, 0); // Activa el driver
    ESP_LOGI(TAG, "Motor inicializado");
}

void stepper_motor_enable(stepper_motor_t *motor) {
    gpio_set_level(motor->enable_pin, 0);
    ESP_LOGI(TAG, "Motor habilitado");
}

void stepper_motor_disable(stepper_motor_t *motor) {
    gpio_set_level(motor->enable_pin, 1);
    ESP_LOGI(TAG, "Motor deshabilitado");
}

void stepper_motor_step(stepper_motor_t *motor, int steps, bool direction, int delay_us) {
    gpio_set_level(motor->dir_pin, direction);

    for (int i = 0; i < steps; i++) {
        gpio_set_level(motor->step_pin, 1);
        esp_rom_delay_us(delay_us);
        gpio_set_level(motor->step_pin, 0);
        esp_rom_delay_us(delay_us);

        // Cada 1000 pasos, cede el CPU brevemente al RTOS
        if (i % 1000 == 0) {
            vTaskDelay(1); // cede tiempo mínimo (1 tick)
        }
    }

    ESP_LOGI(TAG, "Movimiento completo: %d pasos en dirección %d", steps, direction);
    printf("[MOTOR] %d pasos en dirección %s\n", steps, direction ? "IZQ" : "DER");
}

