#include "pid_control.h"

void pid_init(PID_t *pid, float kp, float ki, float kd, float salida_min, float salida_max) {
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;

    pid->error_anterior = 0.0f;
    pid->integral = 0.0f;

    pid->salida_min = salida_min;
    pid->salida_max = salida_max;
}

float pid_compute(PID_t *pid, float referencia, float medicion) {
    float error = referencia - medicion;

    pid->integral += error;
    float derivada = error - pid->error_anterior;

    float salida = pid->kp * error + pid->ki * pid->integral + pid->kd * derivada;

    // Anti-windup y límites
    if (salida > pid->salida_max) salida = pid->salida_max;
    if (salida < pid->salida_min) salida = pid->salida_min;

    pid->error_anterior = error;

    return salida;
}
