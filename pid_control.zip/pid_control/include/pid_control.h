#pragma once

typedef struct {
    float kp;
    float ki;
    float kd;

    float error_anterior;
    float integral;

    float salida_min;
    float salida_max;
} PID_t;

// Inicializa el PID con constantes y límites de salida
void pid_init(PID_t *pid, float kp, float ki, float kd, float salida_min, float salida_max);

// Calcula la salida del PID dados la referencia y la medición actual
float pid_compute(PID_t *pid, float referencia, float medicion);
